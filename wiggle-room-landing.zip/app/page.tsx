"use client"

import type React from "react"

import { useState } from "react"
import ChatInterface from "@/components/chat-interface"
import { Button } from "@/components/ui/button"
import { Calendar, MessageCircle, Sparkles, Heart } from "lucide-react"

export default function HomePage() {
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  // Habit tracking preview data
  const [currentStreak] = useState(3)
  const [weeklyWiggles] = useState(4)
  const [weeklyData] = useState([
    { day: "Sun", emoji: "🌱", completed: true, color: "bg-green-400" },
    { day: "Mon", emoji: "💚", completed: true, color: "bg-green-500" },
    { day: "Tue", emoji: "✨", completed: true, color: "bg-yellow-400" },
    { day: "Wed", emoji: "🎯", completed: true, color: "bg-purple-400" },
    { day: "Thu", emoji: "⭐", completed: false, color: "bg-yellow-300" },
    { day: "Fri", emoji: "", completed: false, color: "bg-gray-200" },
    { day: "Sat", emoji: "", completed: false, color: "bg-gray-200" },
  ])

  // Mood options
  const moodOptions = [
    { emoji: "😴", label: "Tired" },
    { emoji: "😐", label: "Meh" },
    { emoji: "🙂", label: "Good" },
    { emoji: "😊", label: "Great" },
    { emoji: "🤩", label: "Amazing" },
  ]
  const [selectedMood, setSelectedMood] = useState<(typeof moodOptions)[0] | null>(null)

  function selectMood(mood: (typeof moodOptions)[0]) {
    setSelectedMood(mood)
  }

  function showAuth() {
    setShowAuthModal(true)
  }

  function closeAuth() {
    setShowAuthModal(false)
  }

  function handleAuth(event: React.FormEvent) {
    event.preventDefault()
    // TODO: Implement real auth
    console.log("Auth attempt:", { email })
    closeAuth()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50">
      {/* Header */}
      <header className="container mx-auto px-4 py-4">
        <nav className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <span className="text-2xl">🩰</span>
            <span className="text-xl font-semibold text-gray-800">The Wiggle Room</span>
          </div>
          {!isLoggedIn && (
            <Button
              onClick={showAuth}
              variant="ghost"
              className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors"
            >
              Sign Up Free
            </Button>
          )}
        </nav>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8 max-w-7xl mx-auto">
          {/* Left Side - Welcome & Features */}
          <div className="space-y-8">
            {/* Hero Section */}
            <div className="text-center lg:text-left">
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4 leading-tight">
                You don't need a six-pack.
                <br />
                <span className="text-green-600">You need a nudge.</span>
              </h1>
              <p className="text-xl text-gray-600 mb-6 leading-relaxed">
                Your gentle space for movement, mindfulness, and self-care. AI-powered coaching that adapts to your
                energy, schedule, and mood.
              </p>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <p className="text-blue-800 text-sm font-medium">
                  👈 Try the chat now! No signup required. Your progress saves when you create an account.
                </p>
              </div>
            </div>

            {/* Habit Tracking Preview */}
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg">
              <div className="flex items-center space-x-2 mb-4">
                <Calendar className="w-5 h-5 text-green-600" />
                <h3 className="text-xl font-semibold text-gray-800">This Week's Wiggles</h3>
              </div>

              <div className="grid grid-cols-7 gap-2 mb-6">
                {weeklyData.map((day) => (
                  <div key={day.day} className="text-center">
                    <div className="text-xs text-gray-500 mb-1">{day.day}</div>
                    <div className={`w-10 h-10 ${day.color} rounded-full flex items-center justify-center text-sm`}>
                      {day.emoji}
                    </div>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-green-50 rounded-lg p-3 text-center">
                  <div className="text-xl font-bold text-green-600">{currentStreak}</div>
                  <div className="text-xs text-gray-600">Day Streak</div>
                </div>
                <div className="bg-purple-50 rounded-lg p-3 text-center">
                  <div className="text-xl font-bold text-purple-600">{weeklyWiggles}</div>
                  <div className="text-xs text-gray-600">This Week</div>
                </div>
              </div>
            </div>

            {/* Mood Selector */}
            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg">
              <div className="flex items-center space-x-2 mb-4">
                <Sparkles className="w-5 h-5 text-purple-600" />
                <h3 className="text-xl font-semibold text-gray-800">How are you feeling?</h3>
              </div>

              <div className="grid grid-cols-5 gap-2 mb-4">
                {moodOptions.map((mood) => (
                  <button
                    key={mood.label}
                    onClick={() => selectMood(mood)}
                    className={`p-3 rounded-lg text-2xl hover:bg-gray-100 transition-colors ${
                      selectedMood?.label === mood.label ? "bg-blue-100 ring-2 ring-blue-300" : ""
                    }`}
                  >
                    {mood.emoji}
                  </button>
                ))}
              </div>

              <p className="text-sm text-gray-600 text-center">
                Your mood helps the AI suggest perfect movements for today
              </p>
            </div>

            {/* Features */}
            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 text-center">
                <MessageCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <h4 className="font-semibold text-gray-800 mb-1">AI Coach</h4>
                <p className="text-xs text-gray-600">Conversational guidance that adapts to you</p>
              </div>
              <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 text-center">
                <Calendar className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <h4 className="font-semibold text-gray-800 mb-1">No-Shame Tracking</h4>
                <p className="text-xs text-gray-600">Emoji-based progress, effort over perfection</p>
              </div>
              <div className="bg-white/60 backdrop-blur-sm rounded-xl p-4 text-center">
                <Heart className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                <h4 className="font-semibold text-gray-800 mb-1">Your Pace</h4>
                <p className="text-xs text-gray-600">Movement that fits your real life</p>
              </div>
            </div>

            {/* Auth CTA */}
            {!isLoggedIn && (
              <div className="bg-gradient-to-r from-green-100 to-purple-100 rounded-2xl p-6 text-center">
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Love what you see?</h3>
                <p className="text-gray-600 mb-4">
                  Sign up free to save your progress and unlock personalized coaching!
                </p>
                <Button
                  onClick={showAuth}
                  className="bg-gradient-to-r from-green-500 to-purple-500 hover:from-green-600 hover:to-purple-600 text-white px-6 py-3 rounded-lg font-medium transition-all shadow-lg hover:shadow-xl"
                >
                  Start Your Journey Free
                </Button>
              </div>
            )}
          </div>

          {/* Right Side - Chat Interface */}
          <div className="lg:sticky lg:top-8">
            <ChatInterface />

            {/* Chat Benefits */}
            <div className="mt-4 bg-white/60 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-semibold text-gray-800 mb-2">Try it now!</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• No signup required to chat</li>
                <li>• Get personalized movement suggestions</li>
                <li>• Experience gentle, judgment-free coaching</li>
                <li>• Sign up to save your progress</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Auth Modal */}
      {showAuthModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full">
            <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">Join The Wiggle Room</h2>

            <form onSubmit={handleAuth} className="space-y-4">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email"
                required
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
              />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Create a password"
                required
                className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
              />
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-green-500 to-purple-500 hover:from-green-600 hover:to-purple-600 text-white py-3 rounded-lg font-medium transition-all"
              >
                Start Wiggling Free
              </Button>
            </form>

            <Button
              onClick={closeAuth}
              variant="ghost"
              className="w-full mt-4 text-gray-500 hover:text-gray-700 transition-colors"
            >
              Maybe later
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
