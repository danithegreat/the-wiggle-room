<!-- Button.svelte -->
<script lang="ts">
  let { children, type = 'button', disabled, onclick, ...rest } = $props();
</script>

<button
  {type}
  {disabled}
  class="inline-flex items-center justify-center transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed {rest.class || ''}"
  {onclick}
  {...rest}
>
  {@render children?.()}
</button>
